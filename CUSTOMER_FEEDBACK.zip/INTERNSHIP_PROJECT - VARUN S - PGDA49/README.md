# Customer Feedback Analysis & Automated Response

A Python solution that filters critical customer reviews with plain rule-based logic (no machine learning) and uses Generative AI (Google Gemini) to draft personalised, empathetic apology emails for the most urgent cases.

Built for the Imarticus Data Science Internship assessment (Python Foundations & Gen AI).

---

## Project structure

```
final draft/
├── customer_review_dataset_from_kaggle        # Contain the main dataset csv
├── customer_review_analyser_(VARUN.S).ipynb   # Main deliverable: full pipeline with outputs
├── feedback_engine.py                         # Optional reusable module (same logic, also supports OpenAI)
├── .env.example                               # Template for your API key
├── .gitignore                                 # Keeps .env and generated CSVs out of Git
└── README.md
```

The notebook is self-contained and does **not** import `feedback_engine.py`. The module is a packaged version of the same pipeline for reuse in scripts or apps.

---

## Dataset

The notebook was run on a Kaggle/Amazon-style review file (`redmi6.csv`, 280 reviews of the Redmi 6 Pro) with these columns: `Review Title`, `Customer name`, `Rating` (e.g. "4.0 out of 5 stars"), `Date`, `Category`, `Comments`, `Useful`.

The dataset is not bundled in the repo. You can use the same file or any other review dataset (CSV, TSV, TXT, Excel or JSON). The notebook detects the separator, encoding, review column and rating column automatically, and lets you override the guesses.

---

## Approach

### 1. Data cleaning (Pandas)

| Step | What it does |
|---|---|
| Load | Tries several encodings (UTF-8, cp1252, Latin-1) and guesses the separator; skips bad lines. |
| Column detection | Finds review text, title, rating, customer name, email and ID from column names and contents. |
| Rating conversion | Converts "4.0 out of 5 stars", 1-10 scales, percentages or labels (positive/negative) to a 1-5 star scale. |
| Missing values | Rows with no review text or no readable rating are removed. Optional fields (name, email, order ID) are filled with empty strings. |
| Duplicates | Rows with identical review text, customer and order ID are removed (36 found in the sample file). |
| Text cleaning | Decodes HTML entities, lowercases, removes URLs and HTML tags, expands contractions (`don't` to `do not`), strips punctuation and digits, collapses whitespace. |
| Audit trail | Every step logs rows before/after, shown in a cleaning summary table. |

The original text is kept in `review_text` (used for the emails). The cleaned text goes in `clean_text` (used for analysis).

Sample run: 280 rows in, 37 removed, 243 clean rows.

### 2. Rule-based filtering and insights (no ML)

- **Critical reviews** are those with `rating <= 2` (configurable via `CRITICAL_MAX_RATING`).
- **Priority levels** by stars: 1 = P1 Critical, 2 = P2 High, 3 = P3 Medium, 4-5 = P4 Low.
- **Urgency score** ranks reviews within the critical group:
  - 2 points per complaint keyword (from a themed lexicon: Delivery, Quality/Damage, Customer Service, Wrong Item/Size, Refund/Billing, General Dissatisfaction)
  - 4 points per urgency phrase (e.g. "fraud", "chargeback", "still waiting")
  - up to 3 points for exclamation marks
  - up to 5 points for review length (more detail)
  - 2 points per extra complaint theme
- **Complaint keywords**: `collections.Counter` over the cleaned critical reviews, after removing stopwords and words of 2 characters or fewer. Top 15 are shown.
- **Complaint themes**: how many critical reviews touch each theme.

### 3. Automated outreach (Generative AI)

- The top 3 critical reviews (highest star priority, then highest urgency score) are sent to the Gemini API.
- The prompt makes the model act as a **Customer Support Agent**. It reads the whole review, picks a tone (Empathetic, Apologetic, Reassuring, Friendly, Grateful or Formal), and returns JSON containing the tone, the reason, an email subject, an email body of at most 130 words, and internal action steps for the support team.
- The email must apologise, acknowledge each specific complaint, state a concrete fix without inventing order numbers or policies, and sign off as "Customer Care Team".
- Models are tried in order: `gemini-2.5-flash`, then `gemini-2.0-flash`, then `gemini-1.5-flash`.
- **Fallback:** if there is no API key or every model call fails, a rule-based template email is used instead. Each email is labelled with its source (`Google Gemini (<model>)` or `Offline template (not AI)`), so you can always tell which one you are looking at. Make sure all 3 emails show a Gemini label before submitting.

---

## How to run

### Requirements

- Python 3.9+
- Jupyter Notebook / JupyterLab, or Google Colab
- A free Gemini API key: https://aistudio.google.com/app/apikey

### Local (Jupyter)

```bash
pip install pandas openpyxl google-genai ipywidgets jupyter
jupyter notebook "customer_review_analyser_(VARUN.S).ipynb"
```

### Google Colab

Upload the notebook, then run all cells. The first code cell installs the libraries.

### Supplying the API key

Use **one** of these options:

1. **`.env` file (local):** copy `.env.example` to a new file named exactly `.env` and put your key in it:
   ```
   GEMINI_API_KEY=your_key_here
   ```
2. **Colab Secrets:** click the key icon in the left sidebar, add a secret named `GEMINI_API_KEY`, and enable notebook access.
3. **Environment variable:**
   ```bash
   export GEMINI_API_KEY=your_key_here        # macOS / Linux
   setx GEMINI_API_KEY "your_key_here"        # Windows
   ```

Never commit your real key. `.env` is already listed in `.gitignore`.

### Running the notebook

1. Run Section 1 (setup). Adjust `CRITICAL_MAX_RATING`, `N_EMAILS` or `TOP_N_KEYWORDS` if you like.
2. Section 2: upload your review file, or set `CSV_PATH = "your_file.csv"` to skip the upload widget.
3. Run Sections 3-6 to read, clean and analyse the data. Check the "Columns being used" printout, and override the column names in the marked cell if a guess is wrong.
4. Run Sections 7-8 to generate and display the 3 emails.
5. Section 9 saves `cleaned_reviews.csv` and `reply_drafts.csv` next to the notebook.

### Using the module directly (optional)

```python
import feedback_engine as fe

cols = fe.detect_columns(df)
clean_df, report = fe.clean_dataframe(df, cols)
critical = fe.prioritize(clean_df)
print(fe.top_keywords(critical["clean_text"]))

reply = fe.generate_response(
    critical.iloc[0]["review_text"], critical.iloc[0]["rating"],
    themes=critical.iloc[0]["themes"], provider="Google Gemini")   # or "OpenAI" / "Offline template"
```

For OpenAI, install `openai` and set `OPENAI_API_KEY`.

---

## Output artifacts

- Cleaning summary table (rows in/out per step)
- Rating distribution of the cleaned dataset
- Top 15 complaint keywords and complaint-theme breakdown (markdown tables)
- Priority queue of critical reviews
- 3 generated reply emails with tone, subject and internal action steps (markdown)
- `cleaned_reviews.csv`, `reply_drafts.csv`

---

## Limitations

- Keyword and theme lexicons are English only.
- The theme lexicon is generic retail vocabulary, so product-specific words (e.g. "camera", "phone") appear in the keyword counts but not in the themes.
- Rule-based scoring is transparent but approximate: it counts words and does not understand context or negation.
- The Gemini model names and free-tier quotas change over time. If a call returns 404, update `GEMINI_MODELS` in Section 1.
