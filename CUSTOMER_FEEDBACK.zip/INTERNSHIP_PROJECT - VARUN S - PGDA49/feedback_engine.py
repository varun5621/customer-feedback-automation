"""
Core logic for the Customer Feedback Analysis & Automated Response system.

Pipeline (matches the assessment PDF):
  1. Data wrangling  (Pandas)          -> load_file, detect_columns, clean_dataframe
  2. Rule-based filtering (NO ML)      -> prioritize, top_keywords, theme_counts
  3. Gen AI outreach                   -> generate_response (Gemini / OpenAI / offline fallback)
"""
import io
import json
import os
import re
from collections import Counter

import pandas as pd

# --------------------------------------------------------------------------- #
# .env support: put GEMINI_API_KEY=... in a file named .env next to this script
# --------------------------------------------------------------------------- #
def load_env():
    """Read KEY=value lines from .env (current folder or this file's folder) into os.environ. Values in .env win."""
    for folder in (os.getcwd(), os.path.dirname(os.path.abspath(__file__))):
        path = os.path.join(folder, ".env")
        if not os.path.exists(path):
            continue
        for line in open(path, encoding="utf-8-sig"):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.replace("export ", "", 1).split("=", 1)
            value = value.strip().strip("\"'")
            if value and not value.lower().startswith("your"):       # ignore the placeholder from .env.example
                os.environ[key.strip()] = value
        return True
    return False


load_env()


# --------------------------------------------------------------------------- #
# Configuration / rule lexicons
# --------------------------------------------------------------------------- #
STOPWORDS = set("""a about above after again all am an and any are as at be because been before being below between both but by
can did do does doing down during each few for from further had has have having he her here hers him his how i if in into is it its
just me more most my no nor not of off on once only or other our out over own same she should so some such than that the their
them then there these they this those through to too under until up very was we were what when where which while who why will with
would you your also get got one could really much even still bought ordered order item purchase first day like nothing back came""".split())

# Complaint themes -> (terms that signal the theme, customer-facing fix, internal action steps)
THEMES = {
    "Delivery": {
        "terms": ["late", "delay", "delayed", "slow", "never arrived", "not arrived", "lost", "shipping", "waiting", "wait"],
        "fix": "we will trace your parcel right away and expedite a replacement, and refund your shipping charges",
        "steps": ["Check courier tracking and escalate to the logistics partner",
                  "Ship a replacement with express delivery if the parcel is lost",
                  "Refund shipping fees / add a goodwill coupon"],
    },
    "Quality / Damage": {
        "terms": ["broken", "broke", "ripped", "torn", "damaged", "defective", "cheap", "poor", "faded", "shrunk", "shrink",
                  "stitching", "fell off", "smell", "smells", "stain", "stained", "flimsy", "peeling", "leaking"],
        "fix": "we will send a free replacement or a full refund, whichever you prefer, with no need to return the damaged item",
        "steps": ["Ask customer for a photo of the defect (optional, do not delay resolution)",
                  "Issue replacement or full refund",
                  "Log the product ID with the QA team for a supplier check"],
    },
    "Customer Service": {
        "terms": ["rude", "ignored", "unhelpful", "refused", "customer service", "no response", "unprofessional", "hung up", "nobody"],
        "fix": "a senior support manager will personally contact you within 24 hours to make this right",
        "steps": ["Escalate to a team lead / support manager",
                  "Call the customer back within 24 hours",
                  "Review the earlier interaction and coach the agent involved"],
    },
    "Wrong Item / Size": {
        "terms": ["wrong", "size", "tight", "small", "too big", "too large", "different", "photos", "misleading", "not as described", "mismatch"],
        "fix": "we will arrange a free pick-up and ship the correct item or size at no extra cost",
        "steps": ["Generate a prepaid return label",
                  "Dispatch the correct item/size with priority",
                  "Flag the product listing if images/size chart are misleading"],
    },
    "Refund / Billing": {
        "terms": ["refund", "waste", "overpriced", "money", "return", "returning", "charged", "charge", "twice", "billing", "overcharged"],
        "fix": "we will process your refund immediately and confirm the timeline in writing",
        "steps": ["Verify the order and payment in the billing system",
                  "Process refund (typically 3-5 business days) and send confirmation",
                  "Fix any duplicate/incorrect charge found"],
    },
    "General Dissatisfaction": {
        "terms": ["terrible", "awful", "disappointed", "disappointing", "horrible", "worst", "disgusting", "unacceptable", "useless"],
        "fix": "we would like to understand what went wrong and offer you a suitable remedy",
        "steps": ["Reach out personally to understand the issue",
                  "Offer a remedy (refund, replacement or store credit)"],
    },
}

# Words/phrases that signal *urgency* or escalation risk (weighted higher in the score)
URGENCY_TERMS = ["urgent", "urgently", "immediately", "asap", "right now", "emergency", "fraud", "scam", "cheated", "lawsuit",
                 "lawyer", "legal", "chargeback", "report", "consumer court", "complaint", "unsafe", "dangerous", "allergic",
                 "never again", "never buying", "never order", "worst", "still waiting", "no one", "nobody", "twice",
                 "third time", "again and again", "final warning", "cancel"]

CONTRACTIONS = {"n't": " not", "'re": " are", "'ve": " have", "'ll": " will", "'m": " am", "'d": " would"}

# Column-name hints for auto-detection
COLUMN_HINTS = {
    "review": ["review text", "review_text", "review", "text", "feedback", "comment", "comments", "message", "body",
               "description", "ticket", "content", "complaint"],
    "rating": ["rating", "stars", "star", "score", "review score", "review_score"],
    "name": ["customer name", "customer_name", "reviewer name", "reviewer", "username", "name"],
    "email": ["email", "e-mail", "email address", "mail"],
    "id": ["order id", "order_id", "ticket id", "ticket_id", "review id", "clothing id", "product id", "id"],
}


# --------------------------------------------------------------------------- #
# 1. Data wrangling
# --------------------------------------------------------------------------- #
def load_file(uploaded) -> pd.DataFrame:
    """Read an uploaded CSV / Excel file (file-like object with .name) into a DataFrame."""
    name = getattr(uploaded, "name", "").lower()
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(uploaded)
    raw = uploaded.read() if hasattr(uploaded, "read") else uploaded
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(raw), encoding=enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode the CSV file.")


def detect_columns(df: pd.DataFrame) -> dict:
    """Guess which column is review text / rating / name / email / id. Returns {role: column or None}."""
    lowered = {c: str(c).strip().lower() for c in df.columns}
    found = {}
    for role, hints in COLUMN_HINTS.items():
        match = None
        for hint in hints:                      # exact match first, then substring
            match = next((c for c, l in lowered.items() if l == hint and c not in found.values()), None)
            if match:
                break
        if not match:
            for hint in hints:
                if hint in ("name", "id", "text"):      # bare words only match exactly ("Division Name" is not a customer name)
                    continue
                match = next((c for c, l in lowered.items() if hint in l and c not in found.values()), None)
                if match:
                    break
        found[role] = match
    # if 'review' wasn't found, fall back to the column with the longest average text
    if not found["review"]:
        text_cols = [c for c in df.columns if df[c].dtype == object or str(df[c].dtype) in ("str", "string")]
        if text_cols:
            found["review"] = max(text_cols, key=lambda c: df[c].astype(str).str.len().mean())
    return found


def clean_text(text) -> str:
    """lowercase -> expand contractions -> strip URLs/HTML -> remove special chars/digits -> collapse spaces."""
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    for k, v in CONTRACTIONS.items():
        text = text.replace(k, v)
    text = re.sub(r"[^a-z\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def clean_dataframe(df: pd.DataFrame, cols: dict):
    """
    Returns (clean_df, report).
    clean_df has standard columns: review_text, clean_text, rating (+ name/email/id if mapped).
    report = dict of what was removed/filled (shown to the user in the app).
    """
    out = pd.DataFrame(index=df.index)
    out["review_text"] = df[cols["review"]]
    out["rating"] = pd.to_numeric(df[cols["rating"]], errors="coerce") if cols.get("rating") else pd.NA
    for role in ("name", "email", "id"):
        out[role] = df[cols[role]] if cols.get(role) else ""

    report = {"rows_in": len(out)}
    report["missing_review_text"] = int(out["review_text"].isna().sum() + (out["review_text"].astype(str).str.strip() == "").sum())
    out = out[out["review_text"].notna() & (out["review_text"].astype(str).str.strip() != "")]

    if cols.get("rating"):
        report["missing_or_invalid_rating"] = int(out["rating"].isna().sum() + (~out["rating"].dropna().between(1, 5)).sum())
        out = out[out["rating"].between(1, 5)]
        out["rating"] = out["rating"].astype(int)

    for role in ("name", "email", "id"):                # optional fields -> fill blanks
        out[role] = out[role].fillna("").astype(str)

    before = len(out)
    out = out.drop_duplicates(subset=["review_text", "name", "email", "id"])
    report["duplicates_removed"] = before - len(out)

    out["clean_text"] = out["review_text"].apply(clean_text)
    out = out[out["clean_text"] != ""].reset_index(drop=True)
    report["rows_out"] = len(out)
    return out, report


# --------------------------------------------------------------------------- #
# 2. Rule-based filtering & insights (no ML)
# --------------------------------------------------------------------------- #
def _has_term(clean: str, term: str) -> bool:
    return f" {term} " in f" {clean} "


def detect_themes(clean: str) -> list:
    """Return complaint themes found in the text, strongest (most keyword hits) first."""
    hits = {t: sum(_has_term(clean, term) for term in cfg["terms"]) for t, cfg in THEMES.items()}
    return sorted([t for t, h in hits.items() if h], key=lambda t: -hits[t])   # strongest theme first


def prioritize(df: pd.DataFrame, max_rating: int = 2, has_rating: bool = True) -> pd.DataFrame:
    """
    Filter critical reviews and rank them by an explainable urgency score.

    score = 5 (1-star) or 3 (2-star)
          + 2 per complaint keyword hit
          + 4 per urgency phrase
          + 1 per '!' (max 3)
          + word_count / 10 (max 5)   <- more detail = more actionable / complex
          + 2 per extra theme beyond the first (multi-issue = complex)
    Priority: HIGH >= 16, MEDIUM >= 9, else LOW.
    """
    d = df.copy()
    if has_rating:
        d = d[d["rating"] <= max_rating].copy()
    if d.empty:
        return d

    all_terms = [t for cfg in THEMES.values() for t in cfg["terms"]]
    d["themes"] = d["clean_text"].apply(detect_themes)
    d["complaint_hits"] = d["clean_text"].apply(lambda c: sum(_has_term(c, t) for t in all_terms))
    d["urgency_hits"] = d["clean_text"].apply(lambda c: sum(_has_term(c, t) for t in URGENCY_TERMS))
    d["word_count"] = d["clean_text"].str.split().str.len()
    d["exclaims"] = d["review_text"].astype(str).str.count("!").clip(upper=3)

    d["pts_rating"] = d["rating"].map({1: 5, 2: 3}).fillna(0) if has_rating else 0.0
    d["pts_complaint"] = d["complaint_hits"] * 2
    d["pts_urgent"] = d["urgency_hits"] * 4
    d["pts_emphasis"] = d["exclaims"]
    d["pts_detail"] = (d["word_count"] / 10).clip(upper=5).round(1)
    d["pts_multi"] = (d["themes"].str.len() - 1).clip(lower=0) * 2
    d["urgency_score"] = (d["pts_rating"] + d["pts_complaint"] + d["pts_urgent"] + d["pts_emphasis"]
                          + d["pts_detail"] + d["pts_multi"]).round(1)
    d["matched"] = d["clean_text"].apply(lambda c: [t for t in dict.fromkeys(all_terms + URGENCY_TERMS) if _has_term(c, t)])
    if not has_rating:                                   # no stars: keep only reviews with complaint/urgent wording
        d = d[(d["complaint_hits"] + d["urgency_hits"]) > 0].copy()
        if d.empty:
            return d
    d["priority"] = pd.cut(d["urgency_score"], bins=[-1, 8.99, 15.99, 1e9], labels=["LOW", "MEDIUM", "HIGH"])
    d["primary_theme"] = d["themes"].apply(lambda t: t[0] if t else "General Dissatisfaction")
    d = d.drop_duplicates(subset="clean_text")            # avoid identical copy-paste reviews
    return d.sort_values("urgency_score", ascending=False).reset_index(drop=True)


def top_keywords(texts, n: int = 15):
    """Most common non-stopword tokens (len > 2) using collections.Counter."""
    counter = Counter()
    for t in texts:
        counter.update(w for w in t.split() if w not in STOPWORDS and len(w) > 2)
    return counter.most_common(n)


def theme_counts(critical: pd.DataFrame) -> Counter:
    """Number of critical reviews touching each complaint theme."""
    c = Counter()
    for themes in critical["themes"]:
        c.update(themes)
    return c


# --------------------------------------------------------------------------- #
# 3. Generative AI outreach
# --------------------------------------------------------------------------- #
SYSTEM_PROMPT = ("You are a warm, professional Customer Support Agent for a retail company. "
                 "You read the customer's WHOLE message before replying, judge how they feel from what they actually wrote, "
                 "and choose the tone yourself. You write short, personalised replies and propose concrete solutions.")

TONES = ["Empathetic", "Apologetic", "Reassuring", "Friendly", "Grateful", "Formal"]

AUTO_TONE_GUIDE = """Decide the tone YOURSELF after reading the ENTIRE review, every sentence, including any praise or thanks hidden
inside a complaint. Do not decide from the star rating or the first sentence alone. Choose exactly one primary tone:
- Empathetic: the customer sounds hurt, frustrated, disappointed or feels ignored.
- Apologetic: our company clearly made a mistake (late, wrong item, damaged, poor quality).
- Reassuring: the customer is anxious or in a hurry (still waiting, charged twice, needs it urgently, fears a scam).
- Formal: the customer is angry or threatens escalation (chargeback, lawyer, consumer court, reporting us). Stay calm and precise.
- Friendly: the complaint is mild, casual or light-hearted. Match their relaxed style.
- Grateful: the review also contains kind words, loyalty or constructive feedback. Thank them for those specific things first,
  then fix the problem.
If several apply, pick the strongest and blend a second one lightly (for example Apologetic with a thank-you)."""


def build_prompt(review: str, rating, name: str = "", themes=None, tone: str = "Auto", language: str = "English") -> str:
    greet = f"The customer's name is {name}." if name else "The customer's name is unknown; greet them as 'Dear Customer'."
    theme_txt = ", ".join(themes) if themes else "general dissatisfaction"
    rating_txt = f"{rating}-star " if str(rating) not in ("", "<NA>", "nan", "None") else ""
    if tone in TONES:
        tone_rule = f"Use a {tone} tone."
    else:
        tone_rule = AUTO_TONE_GUIDE
    return f"""A customer left this {rating_txt}review / support ticket:

\"\"\"{review}\"\"\"

{greet} Detected complaint themes: {theme_txt}.
{tone_rule}
Write the subject, email and solution steps in {language}.

Return ONLY a valid JSON object (no markdown fences) with exactly these keys:
- "tone": the single tone you chose (one of: {", ".join(TONES)})
- "tone_reason": one short sentence explaining why, quoting or pointing to specific words in the review
- "subject": a short, human email subject line
- "email": the reply email body (max 130 words). It must (1) open in the chosen tone and, whatever the tone, include a sincere apology for the specific problems (these are negative reviews), (2) explicitly acknowledge EACH concrete complaint (and any praise) in the review, (3) state the solution we will provide (refund / replacement / callback etc.) without inventing order numbers, dates or policies, (4) close warmly and sign off as "Customer Care Team".
- "solution": a list of 2-4 short internal action steps for the support employee to resolve this case."""


def _parse_json(text: str):
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    m = re.search(r"\{.*\}", text, flags=re.S)
    return json.loads(m.group(0) if m else text)


POSITIVE_CUES = ["thank", "thanks", "appreciate", "appreciated", "helpful", "love", "loved", "lovely", "nice", "happy",
                 "pleased", "polite", "kind", "great", "wonderful", "excellent", "good"]
LEGAL_CUES = ["lawsuit", "lawyer", "legal", "chargeback", "consumer court", "report", "fraud", "scam", "cheated"]
ANXIOUS_CUES = ["urgent", "urgently", "immediately", "asap", "right now", "still waiting", "twice", "never arrived",
                "not arrived", "waiting", "event"]


def infer_tone(review: str, themes=None):
    """Rule-based stand-in for the AI's tone decision. It reads the WHOLE review. Returns (tone, reason)."""
    clean = clean_text(review)
    legal = [t for t in LEGAL_CUES if _has_term(clean, t)]
    if legal:
        return "Formal", f"The customer mentions escalation ({', '.join(legal[:2])}), so a calm, precise reply fits."
    positive = [t for t in POSITIVE_CUES if _has_term(clean, t)]
    if positive:
        return "Grateful", f"The review includes kind words ({', '.join(positive[:2])}), so we thank them before fixing the problem."
    anxious = [t for t in ANXIOUS_CUES if _has_term(clean, t)]
    if anxious:
        return "Reassuring", f"The customer sounds worried or in a hurry ({', '.join(anxious[:2])})."
    themes = themes or []
    if any(t in themes for t in ("Delivery", "Quality / Damage", "Wrong Item / Size")):
        return "Apologetic", "Something clearly went wrong with the order, so we own the mistake."
    if len(clean.split()) < 12:
        return "Friendly", "The complaint is short and mild, so a relaxed tone fits."
    return "Empathetic", "The customer sounds frustrated or disappointed."


OPENERS = {
    "Empathetic": "Thank you for telling us about your experience, and I am truly sorry.",
    "Apologetic": "I'm sorry we got this wrong, and thank you for letting us know.",
    "Reassuring": "Thank you for reaching out. I understand this is worrying, and I want you to know we are on it right now.",
    "Formal": "Thank you for bringing this matter to our attention. Please accept our sincere apologies.",
    "Friendly": "Thanks so much for letting us know, and I'm really sorry this happened.",
    "Grateful": "Thank you for taking the time to share your feedback, including your kind words. I'm sorry part of your experience fell short.",
}


def offline_response(review: str, name: str = "", themes=None, tone: str = "Auto") -> dict:
    """Rule-based template reply (NOT AI) used when no API key is provided or the API fails."""
    themes = themes or ["General Dissatisfaction"]
    if tone in OPENERS:
        reason = f"You chose the {tone} tone."
    else:
        tone, reason = infer_tone(review, themes)
    cfg = [THEMES[t] for t in themes if t in THEMES] or [THEMES["General Dissatisfaction"]]
    clean = clean_text(review)
    issues = []
    for c in cfg:
        issues += [t for t in c["terms"] if _has_term(clean, t)]
    issues = list(dict.fromkeys(issues))[:4]
    issue_txt = (", ".join(issues)) if issues else "the problems you described"
    fixes = "; ".join(dict.fromkeys(c["fix"] for c in cfg[:2]))
    steps = list(dict.fromkeys(s for c in cfg for s in c["steps"]))[:4]
    greet = f"Dear {name}," if name else "Dear Customer,"
    body = (f"{greet}\n\n{OPENERS[tone]} "
            f"Having to deal with the issues you raised ({issue_txt}) is frustrating, and it is not the standard we hold ourselves to.\n\n"
            f"To put this right, {fixes}. Please simply reply to this email and we will start immediately.\n\n"
            f"Thank you for giving us the chance to make this right.\n\nWarm regards,\nCustomer Care Team")
    return {"subject": "We're sorry - let us make this right", "email": body, "solution": steps,
            "tone": tone, "tone_reason": reason + " (rule-based guess, not AI)"}


def generate_response(review, rating, name="", themes=None, provider="Offline template", api_key="", model="",
                      tone="Auto", language="English"):
    """
    Returns dict(subject, email, solution[list], source).
    provider: 'Google Gemini' | 'OpenAI' | 'Offline template'
    """
    prompt = build_prompt(review, rating, name, themes, tone, language)
    try:
        if provider == "Google Gemini":
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=api_key or os.environ["GEMINI_API_KEY"])
            resp = client.models.generate_content(
                model=model or os.getenv("GEMINI_MODEL", "gemini-2.0-flash"), contents=prompt,
                config=types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT, temperature=0.7))
            data, source = _parse_json(resp.text), "Google Gemini"
        elif provider == "OpenAI":
            from openai import OpenAI
            client = OpenAI(api_key=api_key or os.environ["OPENAI_API_KEY"])
            resp = client.chat.completions.create(
                model=model or os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=0.7,
                messages=[{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}])
            data, source = _parse_json(resp.choices[0].message.content), "OpenAI"
        else:
            note = "" if language == "English" else " - English only"
            return {**offline_response(review, name, themes, tone), "source": "Offline template (not AI)" + note}
        sol = data.get("solution", [])
        if isinstance(sol, str):
            sol = [sol]
        return {"subject": data.get("subject", "We're sorry"), "email": data["email"], "solution": sol, "source": source,
                "tone": data.get("tone") or (tone if tone in TONES else "Auto"), "tone_reason": data.get("tone_reason", "")}
    except Exception as e:                                # never crash the whole batch
        return {**offline_response(review, name, themes, tone), "source": f"Offline template (AI call failed: {str(e)[:120]})"}
